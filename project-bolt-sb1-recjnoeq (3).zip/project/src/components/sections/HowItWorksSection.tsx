import React from 'react';
import { useLanguage } from '../../hooks/useLanguage';
import { Play, Smartphone, Coins, Trophy } from 'lucide-react';

export const HowItWorksSection: React.FC = () => {
  const { t } = useLanguage();

  const steps = [
    {
      icon: <Smartphone className="w-8 h-8" />,
      title: "Download & Setup",
      description: "Install AISleep app and connect your sleep tracking device"
    },
    {
      icon: <Play className="w-8 h-8" />,
      title: "Sleep & Track",
      description: "Sleep naturally while AI monitors your sleep patterns"
    },
    {
      icon: <Coins className="w-8 h-8" />,
      title: "Earn Rewards",
      description: "Wake up to SLEEP tokens based on your sleep quality"
    },
    {
      icon: <Trophy className="w-8 h-8" />,
      title: "Collect NFTs",
      description: "Unlock unique sleep achievement NFTs and build your collection"
    }
  ];

  return (
    <section id="how-it-works" className="py-20 bg-gradient-to-b from-[#0A0A1F] to-[#1A1A3F]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            How It Works
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Transform your sleep into digital value with our revolutionary AI-powered platform
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div
              key={index}
              className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 hover:border-cyan-400/30 transition-all duration-300 group"
            >
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <div className="text-white">
                    {step.icon}
                  </div>
                </div>
                
                <div className="w-8 h-8 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm mb-4">
                  {index + 1}
                </div>
                
                <h3 className="text-xl font-semibold text-white mb-4">
                  {step.title}
                </h3>
                
                <p className="text-gray-300 leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <button className="bg-gradient-to-r from-cyan-400 to-purple-500 text-white px-8 py-4 rounded-full font-semibold text-lg hover:opacity-90 transition-opacity duration-300">
            Get Started Today
          </button>
        </div>
      </div>
    </section>
  );
};